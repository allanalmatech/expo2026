(function () {
    'use strict';

    const toastStack = document.getElementById('toast-stack');

    window.showToast = function (message, type = 'info') {
        if (!toastStack) return;
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        toastStack.appendChild(toast);
        window.setTimeout(() => toast.remove(), 5000);
    };

    document.querySelectorAll('[data-toast]').forEach((toast) => {
        window.setTimeout(() => toast.remove(), 6000);
    });

    const sidebar = document.getElementById('sidebar');
    const publicLinks = document.getElementById('public-links');

    document.addEventListener('click', (event) => {
        const target = event.target;
        if (!(target instanceof Element)) return;

        if (target.matches('[data-sidebar-toggle]')) {
            document.body.classList.toggle('sidebar-open');
        }

        if (target.matches('[data-sidebar-close]')) {
            document.body.classList.remove('sidebar-open');
        }

        if (target.matches('[data-public-nav-toggle]') && publicLinks) {
            publicLinks.classList.toggle('open');
        }
    });

    if (sidebar) {
        sidebar.addEventListener('click', (event) => {
            if (event.target instanceof HTMLAnchorElement) {
                document.body.classList.remove('sidebar-open');
            }
        });
    }

    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            const message = form.getAttribute('data-confirm') || 'Continue with this action?';
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
})();
