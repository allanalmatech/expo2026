(function () {
    'use strict';

    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

    function post(url, data) {
        const body = new FormData();
        Object.entries(data).forEach(([key, value]) => body.append(key, value));
        body.append('csrf_token', token);
        return fetch(url, {
            method: 'POST',
            body,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then((response) => response.json());
    }

    document.addEventListener('change', (event) => {
        const select = event.target;
        if (!(select instanceof HTMLSelectElement) || !select.matches('[data-status-select]')) return;

        select.disabled = true;
        post('../ajax/update-status.php', {
            application_id: select.dataset.id || '',
            field: select.dataset.field || '',
            value: select.value
        }).then((data) => {
            window.showToast?.(data.message || 'Status updated.', data.ok ? 'success' : 'error');
        }).catch(() => {
            window.showToast?.('Unable to update status. Please try again.', 'error');
        }).finally(() => {
            select.disabled = false;
        });
    });

    const filterForm = document.querySelector('[data-filter-applications]');
    const tableBody = document.querySelector('[data-applications-body]');
    let filterTimer = null;
    if (filterForm && tableBody) {
        const runFilter = () => {
            const params = new URLSearchParams(new FormData(filterForm));
            tableBody.classList.add('is-loading');
            fetch(`../ajax/filter-applications.php?${params.toString()}`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then((response) => response.text())
                .then((html) => { tableBody.innerHTML = html; })
                .catch(() => window.showToast?.('Unable to filter applications.', 'error'))
                .finally(() => tableBody.classList.remove('is-loading'));
        };

        filterForm.addEventListener('input', () => {
            window.clearTimeout(filterTimer);
            filterTimer = window.setTimeout(runFilter, 350);
        });
        filterForm.addEventListener('change', runFilter);
        filterForm.addEventListener('submit', (event) => {
            event.preventDefault();
            runFilter();
        });
    }

    document.addEventListener('click', (event) => {
        const button = event.target;
        if (!(button instanceof HTMLButtonElement) || !button.matches('[data-mark-read]')) return;

        button.disabled = true;
        post('../ajax/mark-read.php', { message_id: button.dataset.messageId || '' })
            .then((data) => {
                window.showToast?.(data.message || 'Message updated.', data.ok ? 'success' : 'error');
                if (data.ok) button.closest('.message-card')?.classList.add('is-read');
            })
            .catch(() => window.showToast?.('Unable to mark message as read.', 'error'))
            .finally(() => { button.disabled = false; });
    });
})();
