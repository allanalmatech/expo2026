CREATE TABLE IF NOT EXISTS form_responses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    submitted_at DATETIME NULL,
    full_name VARCHAR(190) NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(60) NULL,
    normalized_phone VARCHAR(30) NULL,
    student_status VARCHAR(120) NULL,
    institution VARCHAR(190) NULL,
    program VARCHAR(190) NULL,
    year_of_study VARCHAR(80) NULL,
    business_name VARCHAR(190) NULL,
    business_nature VARCHAR(190) NULL,
    business_description TEXT NULL,
    applicant_type VARCHAR(120) NULL,
    stall_type VARCHAR(120) NULL,
    number_of_stalls INT UNSIGNED NULL,
    electricity_needed VARCHAR(120) NULL,
    equipment_needed TEXT NULL,
    table_chair_request VARCHAR(190) NULL,
    branding_space_needed VARCHAR(120) NULL,
    preferred_payment_method VARCHAR(120) NULL,
    proof_of_payment_url TEXT NULL,
    rules_agreement VARCHAR(190) NULL,
    raw_data_json LONGTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_form_email (email),
    INDEX idx_form_phone (normalized_phone),
    INDEX idx_form_business (business_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    form_response_id INT UNSIGNED NULL,
    full_name VARCHAR(190) NOT NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(60) NULL,
    normalized_phone VARCHAR(30) NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('applicant', 'admin') NOT NULL DEFAULT 'applicant',
    is_verified TINYINT(1) NOT NULL DEFAULT 0,
    account_status VARCHAR(30) NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_form_response (form_response_id),
    UNIQUE KEY uniq_user_email (email),
    UNIQUE KEY uniq_user_phone (normalized_phone),
    INDEX idx_user_role (role),
    CONSTRAINT fk_users_form_response FOREIGN KEY (form_response_id) REFERENCES form_responses(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS applications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    form_response_id INT UNSIGNED NULL,
    application_status ENUM('Pending Review', 'Needs Correction', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending Review',
    payment_status ENUM('Not Paid', 'Pending Verification', 'Payment Received', 'Payment Rejected') NOT NULL DEFAULT 'Not Paid',
    compliance_status ENUM('Not Signed', 'Signed', 'Pending Review') NOT NULL DEFAULT 'Not Signed',
    assigned_stall_number VARCHAR(80) NULL,
    assigned_stall_location VARCHAR(190) NULL,
    admin_notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_application_user (user_id),
    INDEX idx_application_form_response (form_response_id),
    INDEX idx_application_status (application_status),
    INDEX idx_payment_status (payment_status),
    CONSTRAINT fk_applications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_applications_form_response FOREIGN KEY (form_response_id) REFERENCES form_responses(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_uploads (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    application_id INT UNSIGNED NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    file_type VARCHAR(20) NOT NULL,
    file_size INT UNSIGNED NOT NULL,
    verification_status ENUM('Pending', 'Verified', 'Rejected') NOT NULL DEFAULT 'Pending',
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    verified_by INT UNSIGNED NULL,
    verified_at DATETIME NULL,
    admin_comment TEXT NULL,
    INDEX idx_payment_application (application_id),
    INDEX idx_payment_status (verification_status),
    CONSTRAINT fk_payment_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_payment_application FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    CONSTRAINT fk_payment_verified_by FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sender_id INT UNSIGNED NOT NULL,
    receiver_id INT UNSIGNED NULL,
    title VARCHAR(190) NOT NULL,
    body TEXT NOT NULL,
    message_type ENUM('direct', 'announcement') NOT NULL DEFAULT 'direct',
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_message_receiver (receiver_id),
    INDEX idx_message_type (message_type),
    CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_messages_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcement_recipients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    read_at DATETIME NULL,
    UNIQUE KEY uniq_announcement_user (announcement_id, user_id),
    CONSTRAINT fk_announcement_message FOREIGN KEY (announcement_id) REFERENCES messages(id) ON DELETE CASCADE,
    CONSTRAINT fk_announcement_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stalls (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stall_number VARCHAR(80) NOT NULL,
    stall_location VARCHAR(190) NULL,
    stall_type VARCHAR(120) NULL,
    is_allocated TINYINT(1) NOT NULL DEFAULT 0,
    allocated_to_user_id INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_stall_number (stall_number),
    INDEX idx_stall_allocated (is_allocated),
    CONSTRAINT fk_stall_user FOREIGN KEY (allocated_to_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS compliance_documents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    application_id INT UNSIGNED NOT NULL,
    document_status ENUM('Not Signed', 'Signed', 'Pending Review') NOT NULL DEFAULT 'Not Signed',
    signed_at DATETIME NULL,
    file_path VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_compliance_application (application_id),
    CONSTRAINT fk_compliance_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_compliance_application FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS portal_settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(120) NOT NULL,
    setting_value TEXT NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY uniq_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO portal_settings (setting_key, setting_value, updated_at) VALUES
('event_name', 'Freshers Expo 2026', NOW()),
('event_dates', 'Dates to be announced', NOW()),
('contact_phone', '+256 700 000000', NOW()),
('contact_email', 'expo@must.ac.ug', NOW()),
('google_form_url', '#', NOW()),
('rules_text', 'By participating in the event, all stall holders agree to operate only within their allocated space, keep their stall clean and safe, avoid selling illegal or unauthorized items, follow hygiene requirements where applicable, respect university property, follow security and electrical safety instructions, avoid excessive noise, and comply with all guidance from the organizing committee. Final stall allocation is subject to approval and signing of the compliance document.', NOW())
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW();
