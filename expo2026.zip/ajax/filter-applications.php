<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$admin = require_login('admin');

$filters = application_filters_from_request($_GET);
$rows = fetch_admin_applications(db(), $filters, 150);
header('Content-Type: text/html; charset=utf-8');
echo render_admin_application_rows($rows);
