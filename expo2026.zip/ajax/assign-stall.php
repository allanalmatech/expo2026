<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$admin = require_login('admin');
require_csrf();

$stallId = (int) ($_POST['stall_id'] ?? 0);
$applicationId = (int) ($_POST['application_id'] ?? 0);

$pdo = db();
$stallStatement = $pdo->prepare('SELECT * FROM stalls WHERE id = ? LIMIT 1');
$stallStatement->execute([$stallId]);
$stall = $stallStatement->fetch();

$applicationStatement = $pdo->prepare('SELECT * FROM applications WHERE id = ? LIMIT 1');
$applicationStatement->execute([$applicationId]);
$application = $applicationStatement->fetch();

if (!$stall || !$application) {
    json_response(['ok' => false, 'message' => 'Select a valid stall and application.'], 422);
}

if ((int) $stall['is_allocated'] === 1 && (int) $stall['allocated_to_user_id'] !== (int) $application['user_id']) {
    json_response(['ok' => false, 'message' => 'This stall is already allocated.'], 409);
}

$pdo->beginTransaction();
$pdo->prepare('UPDATE stalls SET is_allocated = 0, allocated_to_user_id = NULL, updated_at = NOW() WHERE allocated_to_user_id = ?')->execute([(int) $application['user_id']]);
$pdo->prepare('UPDATE stalls SET is_allocated = 1, allocated_to_user_id = ?, updated_at = NOW() WHERE id = ?')->execute([(int) $application['user_id'], $stallId]);
$pdo->prepare('UPDATE applications SET assigned_stall_number = ?, assigned_stall_location = ?, updated_at = NOW() WHERE id = ?')->execute([$stall['stall_number'], $stall['stall_location'], $applicationId]);
$pdo->commit();

json_response(['ok' => true, 'message' => 'Stall assigned.']);
