<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool
    {
        return $needle === '' || strpos($haystack, $needle) === 0;
    }
}

if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool
    {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

function secure_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_name('freshers_expo_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

secure_session_start();

function h(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function app_base_path(): string
{
    if (APP_URL !== '') {
        $path = parse_url(APP_URL, PHP_URL_PATH) ?: '';
        return rtrim($path, '/');
    }

    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    foreach (['/public/', '/applicant/', '/admin/', '/ajax/'] as $marker) {
        $position = strpos($script, $marker);
        if ($position !== false) {
            return rtrim(substr($script, 0, $position), '/');
        }
    }

    $directory = rtrim(str_replace('\\', '/', dirname($script)), '/');
    return $directory === '/' ? '' : $directory;
}

function app_url(string $path = ''): string
{
    if (APP_URL !== '') {
        return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
    }

    return app_base_path() . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . app_url($path));
    exit;
}

function normalize_email(?string $email): ?string
{
    $email = strtolower(trim((string) $email));
    return $email === '' ? null : $email;
}

function normalize_phone(?string $phone): ?string
{
    $digits = preg_replace('/\D+/', '', (string) $phone);

    if ($digits === '') {
        return null;
    }

    if (strlen($digits) === 10 && str_starts_with($digits, '0')) {
        return '256' . substr($digits, 1);
    }

    if (strlen($digits) === 9 && str_starts_with($digits, '7')) {
        return '256' . $digits;
    }

    if (strlen($digits) === 13 && str_starts_with($digits, '2560')) {
        return '256' . substr($digits, 4);
    }

    return $digits;
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flash_messages(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function setting(string $key, string $default = ''): string
{
    try {
        $statement = db()->prepare('SELECT setting_value FROM portal_settings WHERE setting_key = ? LIMIT 1');
        $statement->execute([$key]);
        $value = $statement->fetchColumn();
        return $value === false ? $default : (string) $value;
    } catch (Throwable $exception) {
        error_log('Setting read failed: ' . $exception->getMessage());
        return $default;
    }
}

function save_setting(string $key, string $value): void
{
    $statement = db()->prepare(
        'INSERT INTO portal_settings (setting_key, setting_value, updated_at)
         VALUES (?, ?, NOW())
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()'
    );
    $statement->execute([$key, $value]);
}

function badge(string $value): string
{
    $class = status_class($value);
    return '<span class="badge ' . h($class) . '">' . h($value) . '</span>';
}

function status_class(?string $value): string
{
    $value = strtolower((string) $value);

    if (str_contains($value, 'approved') || str_contains($value, 'received') || str_contains($value, 'paid') || str_contains($value, 'signed') || str_contains($value, 'verified')) {
        return 'badge-success';
    }

    if (str_contains($value, 'pending') || str_contains($value, 'review')) {
        return 'badge-warning';
    }

    if (str_contains($value, 'reject') || str_contains($value, 'correction') || str_contains($value, 'not')) {
        return 'badge-danger';
    }

    return 'badge-muted';
}

function initials(?string $name): string
{
    $parts = preg_split('/\s+/', trim((string) $name));
    $letters = '';
    foreach ($parts as $part) {
        if ($part !== '') {
            $letters .= strtoupper(substr($part, 0, 1));
        }
        if (strlen($letters) >= 2) {
            break;
        }
    }
    return $letters !== '' ? $letters : 'FE';
}

function format_date(?string $date): string
{
    if (!$date) {
        return 'Not set';
    }

    $timestamp = strtotime($date);
    return $timestamp ? date('d M Y, H:i', $timestamp) : (string) $date;
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function allowed_upload_extensions(): array
{
    return ['pdf', 'jpg', 'jpeg', 'png'];
}

function validate_uploaded_file(array $file, array $extensions, string &$error): bool
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $error = 'Please choose a valid file to upload.';
        return false;
    }

    if (($file['size'] ?? 0) > APP_MAX_UPLOAD_BYTES) {
        $error = 'The file is too large. Maximum upload size is 5 MB.';
        return false;
    }

    $extension = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $extensions, true)) {
        $error = 'Only PDF, JPG, JPEG, and PNG files are allowed.';
        return false;
    }

    $allowedMime = [
        'pdf' => ['application/pdf', 'application/x-pdf'],
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png' => ['image/png'],
        'csv' => ['text/plain', 'text/csv', 'application/vnd.ms-excel', 'application/octet-stream'],
    ];

    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, (string) $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowedMime[$extension] ?? [], true)) {
            $error = 'The uploaded file type is not allowed.';
            return false;
        }
    }

    return true;
}

function ensure_upload_dir(string $folder): string
{
    $dir = dirname(__DIR__) . '/uploads/' . trim($folder, '/');
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return $dir;
}

function secure_upload_name(string $original): string
{
    $extension = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    return bin2hex(random_bytes(16)) . '.' . $extension;
}

function find_form_response_for_identifier(PDO $pdo, string $identifier): array
{
    $email = normalize_email($identifier);
    if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $statement = $pdo->prepare('SELECT * FROM form_responses WHERE LOWER(email) = ? ORDER BY id DESC LIMIT 1');
        $statement->execute([$email]);
        $row = $statement->fetch();
        if ($row) {
            return ['status' => 'found', 'response' => $row];
        }
    }

    $phone = normalize_phone($identifier);
    if (!$phone) {
        return ['status' => 'invalid'];
    }

    $statement = $pdo->prepare('SELECT * FROM form_responses WHERE normalized_phone = ? ORDER BY id DESC');
    $statement->execute([$phone]);
    $rows = $statement->fetchAll();

    if (count($rows) > 1) {
        return ['status' => 'multiple'];
    }

    if (count($rows) === 1) {
        return ['status' => 'found', 'response' => $rows[0]];
    }

    return ['status' => 'not_found'];
}

function find_user_by_identifier(PDO $pdo, string $identifier): ?array
{
    $email = normalize_email($identifier);
    if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $statement = $pdo->prepare('SELECT * FROM users WHERE LOWER(email) = ? LIMIT 1');
        $statement->execute([$email]);
        $user = $statement->fetch();
        if ($user) {
            return $user;
        }
    }

    $phone = normalize_phone($identifier);
    if ($phone) {
        $statement = $pdo->prepare('SELECT * FROM users WHERE normalized_phone = ? LIMIT 1');
        $statement->execute([$phone]);
        $user = $statement->fetch();
        return $user ?: null;
    }

    return null;
}

function count_rows(string $sql, array $params = []): int
{
    $statement = db()->prepare($sql);
    $statement->execute($params);
    return (int) $statement->fetchColumn();
}

function application_filters_from_request(array $source): array
{
    return [
        'q' => trim((string) ($source['q'] ?? '')),
        'applicant_type' => trim((string) ($source['applicant_type'] ?? '')),
        'business_nature' => trim((string) ($source['business_nature'] ?? '')),
        'application_status' => trim((string) ($source['application_status'] ?? '')),
        'payment_status' => trim((string) ($source['payment_status'] ?? '')),
        'compliance_status' => trim((string) ($source['compliance_status'] ?? '')),
        'stall_type' => trim((string) ($source['stall_type'] ?? '')),
        'electricity_needed' => trim((string) ($source['electricity_needed'] ?? '')),
    ];
}

function fetch_admin_applications(PDO $pdo, array $filters = [], int $limit = 100): array
{
    $conditions = [];
    $params = [];

    if (($filters['q'] ?? '') !== '') {
        $conditions[] = '(u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR fr.business_name LIKE ? OR fr.business_nature LIKE ? OR a.assigned_stall_number LIKE ?)';
        $search = '%' . $filters['q'] . '%';
        array_push($params, $search, $search, $search, $search, $search, $search);
    }

    foreach (['applicant_type', 'business_nature', 'stall_type', 'electricity_needed'] as $field) {
        if (($filters[$field] ?? '') !== '') {
            $conditions[] = 'fr.' . $field . ' = ?';
            $params[] = $filters[$field];
        }
    }

    foreach (['application_status', 'payment_status', 'compliance_status'] as $field) {
        if (($filters[$field] ?? '') !== '') {
            $conditions[] = 'a.' . $field . ' = ?';
            $params[] = $filters[$field];
        }
    }

    $where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
    $sql = "SELECT a.*, u.full_name, u.email, u.phone, fr.business_name, fr.business_nature, fr.applicant_type, fr.stall_type
            FROM applications a
            INNER JOIN users u ON u.id = a.user_id
            LEFT JOIN form_responses fr ON fr.id = a.form_response_id
            $where
            ORDER BY a.updated_at DESC, a.id DESC
            LIMIT " . max(1, min(500, $limit));

    $statement = $pdo->prepare($sql);
    $statement->execute($params);
    return $statement->fetchAll();
}

function render_admin_application_rows(array $rows): string
{
    ob_start();
    foreach ($rows as $row):
        ?>
        <tr>
            <td data-label="Name">
                <div class="identity-cell">
                    <span class="avatar"><?php echo h(initials($row['full_name'] ?? '')); ?></span>
                    <div>
                        <strong><?php echo h($row['full_name'] ?? 'Unknown'); ?></strong>
                        <small><?php echo h($row['applicant_type'] ?? 'Applicant'); ?></small>
                    </div>
                </div>
            </td>
            <td data-label="Business"><?php echo h($row['business_name'] ?? 'Not provided'); ?></td>
            <td data-label="Contact">
                <span><?php echo h($row['email'] ?? ''); ?></span><br>
                <small><?php echo h($row['phone'] ?? ''); ?></small>
            </td>
            <td data-label="Payment"><?php echo badge($row['payment_status'] ?? 'Not Paid'); ?></td>
            <td data-label="Status">
                <select class="compact-select" data-status-select data-field="application_status" data-id="<?php echo (int) $row['id']; ?>">
                    <?php foreach (['Pending Review', 'Needs Correction', 'Approved', 'Rejected'] as $status): ?>
                        <option value="<?php echo h($status); ?>" <?php echo ($row['application_status'] ?? '') === $status ? 'selected' : ''; ?>><?php echo h($status); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td data-label="Assigned Stall"><?php echo h($row['assigned_stall_number'] ?: 'Not assigned'); ?></td>
            <td data-label="Action"><a class="link-strong" href="<?php echo h(app_url('admin/application-view.php?id=' . (int) $row['id'])); ?>">View</a></td>
        </tr>
        <?php
    endforeach;

    if (!$rows):
        ?>
        <tr><td colspan="7" class="empty-state">No applications match the current filters.</td></tr>
        <?php
    endif;

    return ob_get_clean();
}

function form_response_import_fields(): array
{
    return [
        'submitted_at' => 'Submitted At',
        'full_name' => 'Full Name',
        'email' => 'Email',
        'phone' => 'Phone',
        'student_status' => 'Student Status',
        'institution' => 'Institution',
        'program' => 'Program',
        'year_of_study' => 'Year of Study',
        'business_name' => 'Business Name',
        'business_nature' => 'Business Nature',
        'business_description' => 'Business Description',
        'applicant_type' => 'Applicant Type',
        'stall_type' => 'Stall Type',
        'number_of_stalls' => 'Number of Stalls',
        'electricity_needed' => 'Electricity Needed',
        'equipment_needed' => 'Equipment Needed',
        'table_chair_request' => 'Table and Chair Request',
        'branding_space_needed' => 'Branding Space Needed',
        'preferred_payment_method' => 'Preferred Payment Method',
        'proof_of_payment_url' => 'Proof of Payment URL',
        'rules_agreement' => 'Rules Agreement',
    ];
}

function auto_map_column(string $field, array $headers): string
{
    $aliases = [
        'submitted_at' => ['timestamp', 'submitted at', 'submission time', 'date'],
        'full_name' => ['full name', 'name', 'applicant name'],
        'email' => ['email', 'email address'],
        'phone' => ['phone', 'phone number', 'contact', 'contact number'],
        'student_status' => ['student status', 'are you a student'],
        'institution' => ['institution', 'university'],
        'program' => ['program', 'course'],
        'year_of_study' => ['year of study', 'year'],
        'business_name' => ['business name', 'brand name', 'stall name'],
        'business_nature' => ['business nature', 'category', 'type of business'],
        'business_description' => ['business description', 'description'],
        'applicant_type' => ['applicant type', 'vendor type'],
        'stall_type' => ['stall type', 'stall size'],
        'number_of_stalls' => ['number of stalls', 'stalls needed'],
        'electricity_needed' => ['electricity needed', 'power'],
        'equipment_needed' => ['equipment needed', 'equipment'],
        'table_chair_request' => ['table', 'chair', 'table/chair'],
        'branding_space_needed' => ['branding space', 'branding'],
        'preferred_payment_method' => ['payment method', 'preferred payment'],
        'proof_of_payment_url' => ['proof of payment', 'payment proof', 'receipt'],
        'rules_agreement' => ['rules agreement', 'agree', 'consent'],
    ];

    $normalizedHeaders = [];
    foreach ($headers as $index => $header) {
        $normalizedHeaders[(string) $index] = strtolower(trim((string) $header));
    }

    foreach ($aliases[$field] ?? [$field] as $alias) {
        foreach ($normalizedHeaders as $index => $header) {
            if ($header === $alias || str_contains($header, $alias)) {
                return $index;
            }
        }
    }

    return '';
}
