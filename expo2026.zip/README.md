# Freshers Expo Stall Management Portal

Lightweight core PHP and MySQL portal for managing Freshers Expo 2026 stall applications at Mbarara University of Science and Technology.

## Requirements

- PHP 8.0 or newer with PDO MySQL enabled
- MySQL or MariaDB
- Apache shared hosting, cPanel, XAMPP, or similar
- Writable `uploads/` folder

## Install

1. Create a MySQL database with any name, for example `freshers_expo_2026`.
2. Select that database in phpMyAdmin, MySQL CLI, or cPanel, then import `sql/database.sql`.
3. Edit `config/database.php` and set `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASS`.
4. Upload the project files to your hosting folder.
5. Ensure `uploads/`, `uploads/payments/`, `uploads/compliance/`, and `uploads/imports/` are writable by PHP.
6. Open `/admin/create-first-admin.php` once to create the first admin account.
7. Log in at `/login.php` or `/public/login.php`.

## CSV Import Flow

1. Export Google Form responses from Google Sheets as CSV.
2. Log in as admin.
3. Open `Admin > Import CSV` or `/admin/import-responses.php`.
4. Upload the CSV file.
5. Map CSV columns to portal fields.
6. Import responses.

The importer matches existing records by lowercase email first and normalized Uganda phone number second. It updates matching responses and inserts new responses. Applicants can create portal accounts only after their Google Form response has been imported.

## Applicant Account Flow

1. Applicant fills the Google Form.
2. Admin imports the Google Form CSV.
3. Applicant opens `/create-account.php`.
4. Applicant enters the same email or phone number used in the form.
5. Phone numbers such as `0771234567`, `771234567`, `+256771234567`, and `256771234567` normalize to `256771234567`.
6. If a matching response exists and no account exists, the portal creates the user account and linked application record.
7. Applicant logs in to view status, payment, messages, compliance, and stall allocation.

## Upload Security

- Payment and compliance uploads are restricted to PDF, JPG, JPEG, and PNG.
- Maximum upload size is 5 MB.
- Files are renamed with random names.
- `uploads/.htaccess` blocks executable script types and directory listing on Apache.
- Keep upload folders writable but do not place PHP files inside them.

## Admin Features

- Dashboard metrics
- Applicant search and filters
- Application review and correction
- Payment verification
- Direct messages and group announcements
- Stall creation and allocation
- CSV reports for applicants, payments, and stalls
- Portal settings for Google Form link, contacts, event dates, and rules text

## Notes

- No Laravel, React, Vue, Bootstrap, Tailwind, or heavy framework is used.
- Session cookies are HTTP-only and SameSite=Lax.
- Passwords use `password_hash()` and login uses `password_verify()`.
- Database operations use PDO prepared statements.
