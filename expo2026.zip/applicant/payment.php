<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$user = require_login('applicant');
$active = 'payment';
$pageTitle = 'Payment';
$pdo = db();

$statement = $pdo->prepare('SELECT a.*, fr.proof_of_payment_url, fr.preferred_payment_method FROM applications a LEFT JOIN form_responses fr ON fr.id = a.form_response_id WHERE a.user_id = ? LIMIT 1');
$statement->execute([(int) $user['id']]);
$application = $statement->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (!$application) {
        set_flash('error', 'No application record was found for your account.');
        redirect('applicant/payment.php');
    }

    $error = '';
    if (!isset($_FILES['proof']) || !validate_uploaded_file($_FILES['proof'], allowed_upload_extensions(), $error)) {
        set_flash('error', $error ?: 'Please upload a valid payment proof.');
        redirect('applicant/payment.php');
    }

    $dir = ensure_upload_dir('payments');
    $name = secure_upload_name((string) $_FILES['proof']['name']);
    $target = $dir . '/' . $name;
    if (!move_uploaded_file((string) $_FILES['proof']['tmp_name'], $target)) {
        set_flash('error', 'The payment proof could not be saved.');
        redirect('applicant/payment.php');
    }

    $relativePath = 'uploads/payments/' . $name;
    $insert = $pdo->prepare(
        'INSERT INTO payment_uploads (user_id, application_id, file_path, original_filename, file_type, file_size, verification_status, uploaded_at)
         VALUES (?, ?, ?, ?, ?, ?, "Pending", NOW())'
    );
    $insert->execute([
        (int) $user['id'],
        (int) $application['id'],
        $relativePath,
        $_FILES['proof']['name'],
        strtolower(pathinfo((string) $_FILES['proof']['name'], PATHINFO_EXTENSION)),
        (int) $_FILES['proof']['size'],
    ]);

    $update = $pdo->prepare('UPDATE applications SET payment_status = "Pending Verification", updated_at = NOW() WHERE id = ?');
    $update->execute([(int) $application['id']]);

    set_flash('success', 'Payment proof uploaded. The committee can now verify it.');
    redirect('applicant/payment.php');
}

$uploads = [];
if ($application) {
    $uploadsStatement = $pdo->prepare('SELECT * FROM payment_uploads WHERE application_id = ? ORDER BY uploaded_at DESC');
    $uploadsStatement->execute([(int) $application['id']]);
    $uploads = $uploadsStatement->fetchAll();
}

require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-shell">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="page-header">
            <div>
                <h1>Payment Proof</h1>
                <p>Upload proof of payment as PDF, JPG, JPEG, or PNG. Maximum file size is 5 MB.</p>
            </div>
            <?php echo badge($application['payment_status'] ?? 'Not Paid'); ?>
        </div>

        <div class="dashboard-grid">
            <section class="panel">
                <h2>Upload or Replace Proof</h2>
                <form method="post" enctype="multipart/form-data" class="form-grid" data-confirm="Upload this payment proof for committee verification?">
                    <?php echo csrf_field(); ?>
                    <div class="field">
                        <label for="proof">Payment Proof File</label>
                        <input type="file" id="proof" name="proof" accept=".pdf,.jpg,.jpeg,.png" required>
                    </div>
                    <button class="button button-primary" type="submit">Upload Payment Proof</button>
                </form>
            </section>

            <aside class="panel dark-card">
                <h2>Imported Payment</h2>
                <p><strong>Preferred method:</strong> <?php echo h($application['preferred_payment_method'] ?? 'Not provided'); ?></p>
                <?php if (!empty($application['proof_of_payment_url'])): ?>
                    <a class="button button-ghost" href="<?php echo h($application['proof_of_payment_url']); ?>" target="_blank" rel="noopener">View Google Form Proof</a>
                <?php else: ?>
                    <p class="help-text">No proof was imported from the Google Form.</p>
                <?php endif; ?>
            </aside>
        </div>

        <section class="panel" style="margin-top: 22px;">
            <h2>Upload History</h2>
            <div class="table-scroll">
                <table>
                    <thead><tr><th>File</th><th>Status</th><th>Uploaded</th><th>Admin Comment</th></tr></thead>
                    <tbody>
                    <?php foreach ($uploads as $upload): ?>
                        <tr>
                            <td data-label="File"><a class="link-strong" href="<?php echo h(app_url($upload['file_path'])); ?>" target="_blank" rel="noopener"><?php echo h($upload['original_filename']); ?></a></td>
                            <td data-label="Status"><?php echo badge($upload['verification_status']); ?></td>
                            <td data-label="Uploaded"><?php echo h(format_date($upload['uploaded_at'])); ?></td>
                            <td data-label="Admin Comment"><?php echo h($upload['admin_comment'] ?? 'No comment'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$uploads): ?><tr><td colspan="4" class="empty-state">No payment uploads yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
