<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$user = require_login('applicant');
$active = 'stall';
$pageTitle = 'Stall Allocation';

$statement = db()->prepare(
    'SELECT a.*, fr.stall_type, fr.number_of_stalls, fr.electricity_needed, fr.business_name
     FROM applications a
     LEFT JOIN form_responses fr ON fr.id = a.form_response_id
     WHERE a.user_id = ? LIMIT 1'
);
$statement->execute([(int) $user['id']]);
$application = $statement->fetch() ?: null;

require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-shell">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="page-header">
            <div>
                <h1>Stall Allocation</h1>
                <p>Your assigned stall number and location will appear here after approval.</p>
            </div>
            <?php echo badge($application['application_status'] ?? 'Pending Review'); ?>
        </div>

        <section class="panel <?php echo !empty($application['assigned_stall_number']) ? 'dark-card' : ''; ?>">
            <?php if (!empty($application['assigned_stall_number'])): ?>
                <span class="eyebrow">Assigned Stall</span>
                <h2><?php echo h($application['assigned_stall_number']); ?></h2>
                <p><strong>Location:</strong> <?php echo h($application['assigned_stall_location'] ?: 'Location to be confirmed'); ?></p>
                <p><strong>Business:</strong> <?php echo h($application['business_name'] ?? 'Not provided'); ?></p>
                <p><strong>Stall type:</strong> <?php echo h($application['stall_type'] ?? 'Not provided'); ?></p>
            <?php else: ?>
                <div class="empty-state">
                    <h2>Awaiting Allocation</h2>
                    <p>Stall allocation is completed by the committee after application, payment, and compliance review.</p>
                    <a class="button button-primary" href="<?php echo h(app_url('applicant/dashboard.php')); ?>">Return to Dashboard</a>
                </div>
            <?php endif; ?>
        </section>
    </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
