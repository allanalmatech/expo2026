<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$admin = require_login('admin');
$active = 'applications';
$pageTitle = 'Application Review';
$pdo = db();
$applicationId = (int) ($_GET['id'] ?? $_POST['application_id'] ?? 0);

if ($applicationId <= 0) {
    set_flash('error', 'Application not found.');
    redirect('admin/applications.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    try {
        $pdo->beginTransaction();

        $currentStatement = $pdo->prepare('SELECT a.*, u.id AS applicant_user_id FROM applications a INNER JOIN users u ON u.id = a.user_id WHERE a.id = ? LIMIT 1');
        $currentStatement->execute([$applicationId]);
        $current = $currentStatement->fetch();
        if (!$current) {
            throw new RuntimeException('Application missing.');
        }

        $formResponseId = (int) ($_POST['form_response_id'] ?? $current['form_response_id']);
        if ($formResponseId > 0) {
            $responseCheck = $pdo->prepare('SELECT id FROM form_responses WHERE id = ? LIMIT 1');
            $responseCheck->execute([$formResponseId]);
            if (!$responseCheck->fetch()) {
                throw new RuntimeException('Selected form response does not exist.');
            }
            $linkedCheck = $pdo->prepare('SELECT id FROM users WHERE form_response_id = ? AND id <> ? LIMIT 1');
            $linkedCheck->execute([$formResponseId, (int) $current['applicant_user_id']]);
            if ($linkedCheck->fetch()) {
                throw new RuntimeException('Selected form response is already linked to another account.');
            }
        }

        $fullName = trim((string) ($_POST['full_name'] ?? ''));
        $email = normalize_email($_POST['email'] ?? null);
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $normalizedPhone = normalize_phone($phone);

        $pdo->prepare('UPDATE users SET form_response_id = ?, full_name = ?, email = ?, phone = ?, normalized_phone = ?, updated_at = NOW() WHERE id = ?')
            ->execute([$formResponseId ?: null, $fullName ?: 'Applicant', $email, $phone ?: null, $normalizedPhone, (int) $current['applicant_user_id']]);

        $pdo->prepare('UPDATE form_responses SET full_name = ?, email = ?, phone = ?, normalized_phone = ?, business_name = ?, business_nature = ?, business_description = ?, stall_type = ?, updated_at = NOW() WHERE id = ?')
            ->execute([
                $fullName ?: 'Applicant',
                $email,
                $phone ?: null,
                $normalizedPhone,
                trim((string) ($_POST['business_name'] ?? '')),
                trim((string) ($_POST['business_nature'] ?? '')),
                trim((string) ($_POST['business_description'] ?? '')),
                trim((string) ($_POST['stall_type'] ?? '')),
                $formResponseId,
            ]);

        $stallNumber = trim((string) ($_POST['assigned_stall_number'] ?? ''));
        $stallLocation = trim((string) ($_POST['assigned_stall_location'] ?? ''));
        if ($stallNumber !== '') {
            $stallCheck = $pdo->prepare('SELECT * FROM stalls WHERE stall_number = ? LIMIT 1');
            $stallCheck->execute([$stallNumber]);
            $stall = $stallCheck->fetch();
            if ($stall && (int) $stall['is_allocated'] === 1 && (int) $stall['allocated_to_user_id'] !== (int) $current['applicant_user_id']) {
                throw new RuntimeException('That stall is already allocated to another applicant.');
            }
            $pdo->prepare('UPDATE stalls SET is_allocated = 0, allocated_to_user_id = NULL, updated_at = NOW() WHERE allocated_to_user_id = ?')->execute([(int) $current['applicant_user_id']]);
            if ($stall) {
                $pdo->prepare('UPDATE stalls SET stall_location = ?, is_allocated = 1, allocated_to_user_id = ?, updated_at = NOW() WHERE id = ?')
                    ->execute([$stallLocation, (int) $current['applicant_user_id'], (int) $stall['id']]);
            } else {
                $pdo->prepare('INSERT INTO stalls (stall_number, stall_location, stall_type, is_allocated, allocated_to_user_id, created_at, updated_at) VALUES (?, ?, ?, 1, ?, NOW(), NOW())')
                    ->execute([$stallNumber, $stallLocation, trim((string) ($_POST['stall_type'] ?? '')), (int) $current['applicant_user_id']]);
            }
        } else {
            $pdo->prepare('UPDATE stalls SET is_allocated = 0, allocated_to_user_id = NULL, updated_at = NOW() WHERE allocated_to_user_id = ?')->execute([(int) $current['applicant_user_id']]);
        }

        $pdo->prepare(
            'UPDATE applications SET form_response_id = ?, application_status = ?, payment_status = ?, compliance_status = ?, assigned_stall_number = ?, assigned_stall_location = ?, admin_notes = ?, updated_at = NOW() WHERE id = ?'
        )->execute([
            $formResponseId ?: null,
            $_POST['application_status'] ?? 'Pending Review',
            $_POST['payment_status'] ?? 'Not Paid',
            $_POST['compliance_status'] ?? 'Not Signed',
            $stallNumber ?: null,
            $stallLocation ?: null,
            trim((string) ($_POST['admin_notes'] ?? '')),
            $applicationId,
        ]);

        $pdo->commit();
        set_flash('success', 'Application updated successfully.');
        redirect('admin/application-view.php?id=' . $applicationId);
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Application update failed: ' . $exception->getMessage());
        set_flash('error', $exception instanceof RuntimeException ? $exception->getMessage() : 'Unable to update application.');
        redirect('admin/application-view.php?id=' . $applicationId);
    }
}

$statement = $pdo->prepare(
    'SELECT a.*, u.full_name, u.email, u.phone, u.normalized_phone, fr.*,
            a.id AS application_id, u.id AS applicant_user_id
     FROM applications a
     INNER JOIN users u ON u.id = a.user_id
     LEFT JOIN form_responses fr ON fr.id = a.form_response_id
     WHERE a.id = ? LIMIT 1'
);
$statement->execute([$applicationId]);
$application = $statement->fetch();

if (!$application) {
    set_flash('error', 'Application not found.');
    redirect('admin/applications.php');
}

$uploads = $pdo->prepare('SELECT * FROM payment_uploads WHERE application_id = ? ORDER BY uploaded_at DESC');
$uploads->execute([$applicationId]);
$paymentUploads = $uploads->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-shell">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="page-header">
            <div>
                <h1><?php echo h($application['full_name']); ?></h1>
                <p><?php echo h($application['business_name'] ?? 'No business name'); ?> - <?php echo h($application['email'] ?? 'No email'); ?></p>
            </div>
            <a class="button button-ghost" href="<?php echo h(app_url('admin/applications.php')); ?>">Back to Applications</a>
        </div>

        <form method="post" class="dashboard-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="application_id" value="<?php echo (int) $applicationId; ?>">
            <section class="panel">
                <h2>Applicant and Business Details</h2>
                <div class="form-grid two">
                    <div class="field"><label>Form Response ID</label><input type="number" name="form_response_id" value="<?php echo (int) ($application['form_response_id'] ?? 0); ?>" min="0"><small>Use this only to manually relink an applicant to an imported response.</small></div>
                    <div class="field"><label>Full Name</label><input name="full_name" value="<?php echo h($application['full_name']); ?>" required></div>
                    <div class="field"><label>Email</label><input type="email" name="email" value="<?php echo h($application['email']); ?>"></div>
                    <div class="field"><label>Phone</label><input name="phone" value="<?php echo h($application['phone']); ?>"></div>
                    <div class="field"><label>Business Name</label><input name="business_name" value="<?php echo h($application['business_name'] ?? ''); ?>"></div>
                    <div class="field"><label>Business Nature</label><input name="business_nature" value="<?php echo h($application['business_nature'] ?? ''); ?>"></div>
                    <div class="field"><label>Stall Type</label><input name="stall_type" value="<?php echo h($application['stall_type'] ?? ''); ?>"></div>
                </div>
                <div class="field" style="margin-top: 18px;"><label>Business Description</label><textarea name="business_description"><?php echo h($application['business_description'] ?? ''); ?></textarea></div>

                <h2>Review Status</h2>
                <div class="form-grid two">
                    <div class="field"><label>Application Status</label><select name="application_status"><?php foreach (['Pending Review', 'Needs Correction', 'Approved', 'Rejected'] as $option): ?><option <?php echo ($application['application_status'] === $option) ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label>Payment Status</label><select name="payment_status"><?php foreach (['Not Paid', 'Pending Verification', 'Payment Received', 'Payment Rejected'] as $option): ?><option <?php echo ($application['payment_status'] === $option) ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label>Compliance Status</label><select name="compliance_status"><?php foreach (['Not Signed', 'Signed', 'Pending Review'] as $option): ?><option <?php echo ($application['compliance_status'] === $option) ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label>Assigned Stall Number</label><input name="assigned_stall_number" value="<?php echo h($application['assigned_stall_number'] ?? ''); ?>"></div>
                    <div class="field"><label>Assigned Stall Location</label><input name="assigned_stall_location" value="<?php echo h($application['assigned_stall_location'] ?? ''); ?>"></div>
                </div>
                <div class="field" style="margin-top: 18px;"><label>Admin Notes</label><textarea name="admin_notes"><?php echo h($application['admin_notes'] ?? ''); ?></textarea></div>
                <button class="button button-primary" type="submit">Save Review</button>
            </section>

            <aside class="stack">
                <section class="panel dark-card">
                    <h2>Current Status</h2>
                    <p><?php echo badge($application['application_status']); ?> <?php echo badge($application['payment_status']); ?> <?php echo badge($application['compliance_status']); ?></p>
                    <p><strong>Normalized phone:</strong> <?php echo h($application['normalized_phone'] ?? 'Not available'); ?></p>
                </section>
                <section class="panel">
                    <h2>Payment Proof</h2>
                    <?php if (!empty($application['proof_of_payment_url'])): ?><p><a class="link-strong" href="<?php echo h($application['proof_of_payment_url']); ?>" target="_blank" rel="noopener">View imported proof</a></p><?php endif; ?>
                    <?php foreach ($paymentUploads as $upload): ?>
                        <p><a class="link-strong" href="<?php echo h(app_url($upload['file_path'])); ?>" target="_blank" rel="noopener"><?php echo h($upload['original_filename']); ?></a><br><?php echo badge($upload['verification_status']); ?></p>
                    <?php endforeach; ?>
                    <?php if (!$paymentUploads && empty($application['proof_of_payment_url'])): ?><p class="help-text">No payment proof available.</p><?php endif; ?>
                </section>
            </aside>
        </form>
    </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
