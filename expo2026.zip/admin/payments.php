<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$admin = require_login('admin');
$active = 'payments';
$pageTitle = 'Payments';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $uploadId = (int) ($_POST['upload_id'] ?? 0);
    $action = (string) ($_POST['action'] ?? '');
    $comment = trim((string) ($_POST['admin_comment'] ?? ''));
    $status = $action === 'verify' ? 'Verified' : 'Rejected';
    $paymentStatus = $action === 'verify' ? 'Payment Received' : 'Payment Rejected';

    $upload = $pdo->prepare('SELECT * FROM payment_uploads WHERE id = ? LIMIT 1');
    $upload->execute([$uploadId]);
    $row = $upload->fetch();
    if ($row) {
        $pdo->prepare('UPDATE payment_uploads SET verification_status = ?, verified_by = ?, verified_at = NOW(), admin_comment = ? WHERE id = ?')
            ->execute([$status, (int) $admin['id'], $comment, $uploadId]);
        $pdo->prepare('UPDATE applications SET payment_status = ?, updated_at = NOW() WHERE id = ?')
            ->execute([$paymentStatus, (int) $row['application_id']]);
        set_flash('success', 'Payment proof updated.');
    } else {
        set_flash('error', 'Payment upload not found.');
    }
    redirect('admin/payments.php');
}

$statement = $pdo->query(
    'SELECT pu.*, u.full_name, u.email, fr.business_name, a.payment_status
     FROM payment_uploads pu
     INNER JOIN users u ON u.id = pu.user_id
     INNER JOIN applications a ON a.id = pu.application_id
     LEFT JOIN form_responses fr ON fr.id = a.form_response_id
     ORDER BY pu.uploaded_at DESC'
);
$uploads = $statement->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-shell">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="page-header">
            <div>
                <h1>Payment Verification</h1>
                <p>Review uploaded payment proofs and update verification status.</p>
            </div>
        </div>

        <section class="panel">
            <div class="table-scroll">
                <table>
                    <thead><tr><th>Applicant</th><th>Business</th><th>File</th><th>Status</th><th>Comment</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($uploads as $upload): ?>
                        <tr>
                            <td data-label="Applicant"><strong><?php echo h($upload['full_name']); ?></strong><br><small><?php echo h($upload['email']); ?></small></td>
                            <td data-label="Business"><?php echo h($upload['business_name'] ?? 'Not provided'); ?></td>
                            <td data-label="File"><a class="link-strong" href="<?php echo h(app_url($upload['file_path'])); ?>" target="_blank" rel="noopener"><?php echo h($upload['original_filename']); ?></a><br><small><?php echo h(format_date($upload['uploaded_at'])); ?></small></td>
                            <td data-label="Status"><?php echo badge($upload['verification_status']); ?></td>
                            <td data-label="Comment"><?php echo h($upload['admin_comment'] ?? ''); ?></td>
                            <td data-label="Action">
                                <form method="post" class="form-grid" data-confirm="Update this payment verification?">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="upload_id" value="<?php echo (int) $upload['id']; ?>">
                                    <textarea name="admin_comment" placeholder="Admin comment"><?php echo h($upload['admin_comment'] ?? ''); ?></textarea>
                                    <div class="header-actions">
                                        <button class="button button-primary" name="action" value="verify" type="submit">Verify</button>
                                        <button class="button button-danger" name="action" value="reject" type="submit">Reject</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$uploads): ?><tr><td colspan="6" class="empty-state">No payment uploads yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
