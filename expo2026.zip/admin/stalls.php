<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$admin = require_login('admin');
$active = 'stalls';
$pageTitle = 'Stalls';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'save_stall') {
        $stallId = (int) ($_POST['stall_id'] ?? 0);
        $number = trim((string) ($_POST['stall_number'] ?? ''));
        $location = trim((string) ($_POST['stall_location'] ?? ''));
        $type = trim((string) ($_POST['stall_type'] ?? ''));
        if ($number === '') {
            set_flash('error', 'Stall number is required.');
            redirect('admin/stalls.php');
        }
        $duplicate = $pdo->prepare('SELECT id FROM stalls WHERE stall_number = ? AND id <> ? LIMIT 1');
        $duplicate->execute([$number, $stallId]);
        if ($duplicate->fetch()) {
            set_flash('error', 'Another stall already uses that number.');
            redirect('admin/stalls.php');
        }
        if ($stallId > 0) {
            $pdo->prepare('UPDATE stalls SET stall_number = ?, stall_location = ?, stall_type = ?, updated_at = NOW() WHERE id = ?')->execute([$number, $location, $type, $stallId]);
            set_flash('success', 'Stall updated.');
        } else {
            $pdo->prepare('INSERT INTO stalls (stall_number, stall_location, stall_type, is_allocated, created_at, updated_at) VALUES (?, ?, ?, 0, NOW(), NOW())')->execute([$number, $location, $type]);
            set_flash('success', 'Stall created.');
        }
        redirect('admin/stalls.php');
    }

    if ($action === 'assign_stall') {
        $stallId = (int) ($_POST['stall_id'] ?? 0);
        $applicationId = (int) ($_POST['application_id'] ?? 0);
        $stall = $pdo->prepare('SELECT * FROM stalls WHERE id = ? LIMIT 1');
        $stall->execute([$stallId]);
        $stallRow = $stall->fetch();
        $application = $pdo->prepare('SELECT * FROM applications WHERE id = ? LIMIT 1');
        $application->execute([$applicationId]);
        $applicationRow = $application->fetch();
        if (!$stallRow || !$applicationRow) {
            set_flash('error', 'Select a valid stall and application.');
            redirect('admin/stalls.php');
        }
        if ((int) $stallRow['is_allocated'] === 1 && (int) $stallRow['allocated_to_user_id'] !== (int) $applicationRow['user_id']) {
            set_flash('error', 'This stall is already allocated.');
            redirect('admin/stalls.php');
        }
        $pdo->prepare('UPDATE stalls SET is_allocated = 0, allocated_to_user_id = NULL, updated_at = NOW() WHERE allocated_to_user_id = ?')->execute([(int) $applicationRow['user_id']]);
        $pdo->prepare('UPDATE stalls SET is_allocated = 1, allocated_to_user_id = ?, updated_at = NOW() WHERE id = ?')->execute([(int) $applicationRow['user_id'], $stallId]);
        $pdo->prepare('UPDATE applications SET assigned_stall_number = ?, assigned_stall_location = ?, updated_at = NOW() WHERE id = ?')->execute([$stallRow['stall_number'], $stallRow['stall_location'], $applicationId]);
        set_flash('success', 'Stall assigned.');
        redirect('admin/stalls.php');
    }

    if ($action === 'release_stall') {
        $stallId = (int) ($_POST['stall_id'] ?? 0);
        $stall = $pdo->prepare('SELECT * FROM stalls WHERE id = ? LIMIT 1');
        $stall->execute([$stallId]);
        $stallRow = $stall->fetch();
        if ($stallRow) {
            $pdo->prepare('UPDATE applications SET assigned_stall_number = NULL, assigned_stall_location = NULL, updated_at = NOW() WHERE user_id = ?')->execute([(int) $stallRow['allocated_to_user_id']]);
            $pdo->prepare('UPDATE stalls SET is_allocated = 0, allocated_to_user_id = NULL, updated_at = NOW() WHERE id = ?')->execute([$stallId]);
        }
        set_flash('success', 'Stall released.');
        redirect('admin/stalls.php');
    }
}

$stalls = $pdo->query('SELECT s.*, u.full_name, fr.business_name FROM stalls s LEFT JOIN users u ON u.id = s.allocated_to_user_id LEFT JOIN applications a ON a.user_id = u.id LEFT JOIN form_responses fr ON fr.id = a.form_response_id ORDER BY s.stall_number ASC')->fetchAll();
$applications = $pdo->query('SELECT a.id, u.full_name, fr.business_name FROM applications a INNER JOIN users u ON u.id = a.user_id LEFT JOIN form_responses fr ON fr.id = a.form_response_id ORDER BY u.full_name ASC')->fetchAll();
$editStall = null;
if (!empty($_GET['edit'])) {
    $edit = $pdo->prepare('SELECT * FROM stalls WHERE id = ? LIMIT 1');
    $edit->execute([(int) $_GET['edit']]);
    $editStall = $edit->fetch() ?: null;
}

require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-shell">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="page-header">
            <div><h1>Stall Allocation</h1><p>Create stalls, assign applicants, and monitor availability.</p></div>
            <a class="button button-primary" href="<?php echo h(app_url('admin/reports.php?export=stalls')); ?>">Export Stall List</a>
        </div>

        <div class="dashboard-grid">
            <section class="panel">
                <h2>Create or Edit Stall</h2>
                <form method="post" class="form-grid two">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="save_stall">
                    <input type="hidden" name="stall_id" value="<?php echo (int) ($editStall['id'] ?? 0); ?>">
                    <div class="field"><label>Stall Number</label><input name="stall_number" value="<?php echo h($editStall['stall_number'] ?? ''); ?>" required></div>
                    <div class="field"><label>Location</label><input name="stall_location" value="<?php echo h($editStall['stall_location'] ?? ''); ?>"></div>
                    <div class="field"><label>Stall Type</label><input name="stall_type" value="<?php echo h($editStall['stall_type'] ?? ''); ?>"></div>
                    <div class="field"><label>&nbsp;</label><button class="button button-primary" type="submit"><?php echo $editStall ? 'Update Stall' : 'Save Stall'; ?></button></div>
                </form>
            </section>

            <section class="panel dark-card">
                <h2>Assign Stall</h2>
                <form method="post" class="form-grid" data-confirm="Assign selected stall to this applicant?">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="assign_stall">
                    <div class="field"><label>Available Stall</label><select name="stall_id" required><option value="">Select stall</option><?php foreach ($stalls as $stall): ?><option value="<?php echo (int) $stall['id']; ?>" <?php echo (int) $stall['is_allocated'] === 1 ? 'disabled' : ''; ?>><?php echo h($stall['stall_number'] . ' - ' . $stall['stall_location']); ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label>Application</label><select name="application_id" required><option value="">Select applicant</option><?php foreach ($applications as $application): ?><option value="<?php echo (int) $application['id']; ?>"><?php echo h($application['full_name'] . ' - ' . ($application['business_name'] ?? 'No business')); ?></option><?php endforeach; ?></select></div>
                    <button class="button button-primary" type="submit">Assign Stall</button>
                </form>
            </section>
        </div>

        <section class="panel" style="margin-top: 22px;">
            <h2>Stalls</h2>
            <div class="table-scroll">
                <table>
                    <thead><tr><th>Number</th><th>Location</th><th>Type</th><th>Status</th><th>Allocated To</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($stalls as $stall): ?>
                        <tr>
                            <td data-label="Number"><strong><?php echo h($stall['stall_number']); ?></strong></td>
                            <td data-label="Location"><?php echo h($stall['stall_location']); ?></td>
                            <td data-label="Type"><?php echo h($stall['stall_type']); ?></td>
                            <td data-label="Status"><?php echo badge((int) $stall['is_allocated'] === 1 ? 'Allocated' : 'Available'); ?></td>
                            <td data-label="Allocated To"><?php echo h($stall['full_name'] ?? 'Not allocated'); ?><br><small><?php echo h($stall['business_name'] ?? ''); ?></small></td>
                            <td data-label="Action">
                                <a class="link-strong" href="<?php echo h(app_url('admin/stalls.php?edit=' . (int) $stall['id'])); ?>">Edit</a>
                                <?php if ((int) $stall['is_allocated'] === 1): ?>
                                    <form method="post" data-confirm="Release this stall allocation?">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="action" value="release_stall">
                                        <input type="hidden" name="stall_id" value="<?php echo (int) $stall['id']; ?>">
                                        <button class="button button-ghost" type="submit">Release</button>
                                    </form>
                                <?php else: ?>
                                    <span class="help-text">Ready</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$stalls): ?><tr><td colspan="6" class="empty-state">No stalls created yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
