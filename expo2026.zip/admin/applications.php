<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$user = require_login('admin');
$active = 'applications';
$pageTitle = 'Applications';
$pdo = db();
$filters = application_filters_from_request($_GET);
$rows = fetch_admin_applications($pdo, $filters, 100);

$distinct = function (string $field) use ($pdo): array {
    $statement = $pdo->query('SELECT DISTINCT ' . $field . ' AS value FROM form_responses WHERE ' . $field . ' IS NOT NULL AND ' . $field . ' <> "" ORDER BY ' . $field . ' ASC LIMIT 80');
    return array_column($statement->fetchAll(), 'value');
};

require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-shell">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="page-header">
            <div>
                <h1>Applicant Manager</h1>
                <p>Search, filter, review, and update imported vendor profiles.</p>
            </div>
            <div class="header-actions">
                <a class="button button-secondary" href="<?php echo h(app_url('admin/messages.php')); ?>">Bulk Announcement</a>
                <a class="button button-ghost" href="<?php echo h(app_url('admin/messages.php')); ?>">Send Message</a>
                <a class="button button-primary" href="<?php echo h(app_url('admin/reports.php?export=applicants')); ?>">Export CSV</a>
            </div>
        </div>

        <div class="stat-grid">
            <article class="stat-card"><span class="label">Total Applicants</span><strong><?php echo number_format(count_rows('SELECT COUNT(*) FROM users WHERE role = "applicant"')); ?></strong></article>
            <article class="stat-card"><span class="label">Paid Vendors</span><strong><?php echo number_format(count_rows('SELECT COUNT(*) FROM applications WHERE payment_status = "Payment Received"')); ?></strong></article>
            <article class="stat-card"><span class="label">Pending Allocation</span><strong><?php echo number_format(count_rows('SELECT COUNT(*) FROM applications WHERE application_status = "Approved" AND (assigned_stall_number IS NULL OR assigned_stall_number = "")')); ?></strong></article>
            <article class="stat-card"><span class="label">Needs Correction</span><strong><?php echo number_format(count_rows('SELECT COUNT(*) FROM applications WHERE application_status = "Needs Correction"')); ?></strong></article>
        </div>

        <section class="panel">
            <form class="table-toolbar" method="get" data-filter-applications>
                <input type="search" name="q" placeholder="Search applicants, businesses, emails, phones, stalls..." value="<?php echo h($filters['q']); ?>">
                <select name="application_status">
                    <option value="">Any application status</option>
                    <?php foreach (['Pending Review', 'Needs Correction', 'Approved', 'Rejected'] as $option): ?><option <?php echo $filters['application_status'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
                <select name="payment_status">
                    <option value="">Any payment status</option>
                    <?php foreach (['Not Paid', 'Pending Verification', 'Payment Received', 'Payment Rejected'] as $option): ?><option <?php echo $filters['payment_status'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
                <select name="compliance_status">
                    <option value="">Any compliance status</option>
                    <?php foreach (['Not Signed', 'Signed', 'Pending Review'] as $option): ?><option <?php echo $filters['compliance_status'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
                <select name="applicant_type">
                    <option value="">Any applicant type</option>
                    <?php foreach ($distinct('applicant_type') as $option): ?><option value="<?php echo h($option); ?>" <?php echo $filters['applicant_type'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
                <select name="business_nature">
                    <option value="">Any business nature</option>
                    <?php foreach ($distinct('business_nature') as $option): ?><option value="<?php echo h($option); ?>" <?php echo $filters['business_nature'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
                <select name="stall_type">
                    <option value="">Any stall type</option>
                    <?php foreach ($distinct('stall_type') as $option): ?><option value="<?php echo h($option); ?>" <?php echo $filters['stall_type'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
                <select name="electricity_needed">
                    <option value="">Electricity?</option>
                    <?php foreach ($distinct('electricity_needed') as $option): ?><option value="<?php echo h($option); ?>" <?php echo $filters['electricity_needed'] === $option ? 'selected' : ''; ?>><?php echo h($option); ?></option><?php endforeach; ?>
                </select>
            </form>

            <div class="table-scroll">
                <table>
                    <thead><tr><th>Name</th><th>Business</th><th>Contact</th><th>Payment</th><th>Status</th><th>Assigned Stall</th><th>Action</th></tr></thead>
                    <tbody data-applications-body><?php echo render_admin_application_rows($rows); ?></tbody>
                </table>
            </div>
        </section>
    </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
